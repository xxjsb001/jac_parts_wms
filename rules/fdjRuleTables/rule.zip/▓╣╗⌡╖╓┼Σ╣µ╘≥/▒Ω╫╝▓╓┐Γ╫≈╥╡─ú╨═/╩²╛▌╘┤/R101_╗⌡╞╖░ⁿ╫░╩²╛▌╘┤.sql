SELECT 
 PU.ID AS "包装序号",
 PU.UNIT AS "包装单位",
 PU.PU_LEVEL AS "包装级别",
 PU.WEIGHT AS "包装重量",
 PU.VOLUME AS "包装体积",
 PU.CONVERT_FIGURE AS "包装件装量"
 FROM WMS_PACKAGE_UNIT PU
 LEFT JOIN WMS_ITEM ITEM ON ITEM.ID = PU.ITEM_ID
 WHERE 1=1
 /~货品序号: AND PU.ITEM_ID = {货品序号}~/
 /~包装级别: AND PU.PU_LEVEL = {包装级别}~/
